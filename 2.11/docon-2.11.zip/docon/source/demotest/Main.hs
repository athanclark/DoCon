module Main where

import T_

main = test "log"
